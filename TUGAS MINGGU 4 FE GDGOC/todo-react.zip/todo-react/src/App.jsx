import { useState, useEffect } from "react";

function App() {
  const [todos, setTodos] = useState([]);
  const [input, setInput] = useState("");
  const [editId, setEditId] = useState(null);
  const [darkMode, setDarkMode] = useState(false);
  const [idCounter, setIdCounter] = useState(1);

  // Dark mode global (body)
  useEffect(() => {
    if (darkMode) {
      document.body.classList.add("dark-mode");
    } else {
      document.body.classList.remove("dark-mode");
    }
  }, [darkMode]);

  // ADD / UPDATE
  const handleAdd = () => {
    if (!input.trim()) return;

    if (editId !== null) {
      setTodos(
        todos.map((todo) =>
          todo.id === editId ? { ...todo, text: input } : todo
        )
      );
      setEditId(null);
    } else {
      setTodos([...todos, { id: idCounter, text: input }]);
      setIdCounter(idCounter + 1);
    }

    setInput("");
  };

  // DELETE
  const handleDelete = (id) => {
    setTodos(todos.filter((todo) => todo.id !== id));
  };

  // SORT
  const sortAsc = () => {
    setTodos([...todos].sort((a, b) => a.id - b.id));
  };

  const sortDesc = () => {
    setTodos([...todos].sort((a, b) => b.id - a.id));
  };

  return (
    <section className="app-container">

      {/* PROFILE */}
      <div className="card profile-section">
        <div className="profile-header">
          <img
            src="/public/profile.webp"
            alt="Avatar"
            className="avatar"
          />
          <div>
            <h2>Michael William</h2>
            <p className="role">Frontend Developer</p>
          </div>
        </div>

        <p className="bio">
          Sistem Todo List berbasis ReactJS dengan fitur tambah,
          hapus, update, serta filter Asc & Desc.
        </p>

        <button
          className="btn btn-secondary"
          onClick={() => setDarkMode(!darkMode)}
        >
          🌙 Switch Mode
        </button>
      </div>

      {/* TODO LIST */}
      <div className="card">
        <h3>My Tasks</h3>

        <div className="input-group">
          <input
            type="text"
            placeholder="Tulis tugas baru..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
          <button className="btn btn-primary" onClick={handleAdd}>
            {editId ? "Update" : "Add"}
          </button>
        </div>

        <div className="input-group">
          <button className="btn btn-secondary" onClick={sortAsc}>
            ⬆ Asc
          </button>
          <button className="btn btn-secondary" onClick={sortDesc}>
            ⬇ Desc
          </button>
        </div>

        <ul>
          {todos.map((todo) => (
            <li key={todo.id} style={{ opacity: 1 }}>
              <span>{todo.id}. {todo.text}</span>
              <div>
                <button
                  className="btn btn-secondary"
                  onClick={() => {
                    setInput(todo.text);
                    setEditId(todo.id);
                  }}
                >
                  Edit
                </button>
                <button
                  className="btn btn-secondary"
                  onClick={() => handleDelete(todo.id)}
                >
                  Delete
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>

    </section>
  );
}

export default App;
