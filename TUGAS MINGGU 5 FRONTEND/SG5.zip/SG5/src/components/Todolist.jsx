import React, { useState } from "react";
import "../assets/css/todolist.css";

const TodoList = () => {
  const [todo, setTodo] = useState("");

  const [list, setList] = useState([
    {
      id: 1,
      deskripsi: "Belajar ReactJs",
      completed: false,
    },
  ]);

  const addTodoHandler = () => {
    if (todo.trim() === "") return;

    const data = {
      id: Date.now(),
      deskripsi: todo,
      completed: false,
    };

    //jangan pakai push
    setList([...list, data]);
    setTodo("");
  };

  const toggleTodo = (id) => {
    const updatedList = list.map((item) =>
      item.id === id ? { ...item, completed: !item.completed } : item
    );

    setList(updatedList);
  };

  const totalTodo = list.length;
  const completedTodo = list.filter((item) => item.completed).length;

  return (
    <div className="card todo-section">
      <h3>My Tasks</h3>

      <p>
        <b>Todolist selesai {completedTodo} / {totalTodo}</b>
      </p>

      <div className="input-group">
        <input
          type="text"
          placeholder="Tulis tugas baru..."
          value={todo}
          onChange={(e) => setTodo(e.target.value)}
        />
        <button className="btn btn-primary" onClick={addTodoHandler}>
          Add
        </button>
      </div>

      <ul className="todo-list">
        {list.map((item, index) => (
          <li key={item.id} className={item.completed ? "done" : ""}>
            <span>
              <b>{index + 1}</b>{" "}
              {item.completed ? <s>{item.deskripsi}</s> : item.deskripsi}
            </span>

            <button
              className="btn btn-sm"
              onClick={() => toggleTodo(item.id)}
            >
              {item.completed ? "Batal" : "Selesai"}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TodoList;
